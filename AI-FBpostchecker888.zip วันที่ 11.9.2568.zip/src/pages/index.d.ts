/**
 * Placeholder types index for pages (optional)
 * This file exists to satisfy potential TS path resolutions.
 */
