/**
 * Gray Hat Strategy Page
 */

import GrayHatAnalyzer from '../components/GrayHatAnalyzer'

export default function GrayHatPage() {
  return <GrayHatAnalyzer />
}
